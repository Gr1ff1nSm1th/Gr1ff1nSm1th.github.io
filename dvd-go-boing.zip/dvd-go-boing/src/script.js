const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
document.body.appendChild(canvas);
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

//___________________Variables ___________________

let x = 0;
let y = 0;
const speed = 5;
let Vx = speed;
let Vy = speed;
let color = "blue";
document.body.style.backgroundColor = "black";


//___________________Build the Rectangle ___________________


function cycle() {
 let cs = 5
  
  x += Vx;
  y += Vy;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = color;
  let rect = ctx.fillRect(x, y, 200, 100);

  ctx.font = "70px Arial Black";
  ctx.fillStyle = "white";
  ctx.fillText("DVD", x + 50, y + 75, 100);

  //___________________Color Picker___________________

  const rainbowColors = ["red", "orange", "yellow", "green", "blue", "indigo", 
  ];
  const rainbows =
    rainbowColors[Math.floor(Math.random() * rainbowColors.length)];

  //___________________Walls and Such ___________________

  if (x > canvas.width - 175) {
    Vx = -speed;
    color = rainbows;
  }
  if (x < 0) {
    Vx = speed;
    color = rainbows;
  }

  if (y > canvas.height - 100) {
    Vy = -speed;
    color = rainbows;
  }
  if (y < 0) {
    Vy = speed;
    color = rainbows;
  }

  
  
  
  
  
  
  
  //___________________ Confeti Left Side___________________

  
  if( (x < cs && y < cs) || (x < cs && y > canvas.height - cs)){
    const canvas = document.getElementById('confettiCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const colors = ['#ff0b00', '#00ff0b', '#00b3ff', '#ff00b3', '#ffb300'];
const particles = [];
let isAnimating = true; // To control the animation
let fadeOutStartTime = null; // To track fade out start time

function createParticle() {
    const size = Math.random() * 10 + 5;
    particles.push({
        x: Math.random() * canvas.width,
        y: 0,
        size: size,
        color: colors[Math.floor(Math.random() * colors.length)],
        speed: Math.random() * 3 + 1,
        angle: Math.random() * Math.PI * 2,
        opacity: 1 // Start fully opaque
    });
}

function updateParticles() {
    particles.forEach((particle, index) => {
        particle.y += particle.speed;
        particle.x += Math.sin(particle.angle) * 2;

        // Fade out effect
        if (fadeOutStartTime) {
            const elapsedTime = Date.now() - fadeOutStartTime;
            particle.opacity = Math.max(1 - elapsedTime / 2000, 0); // Fade out over 2 seconds
        }

        // Remove particle if it's off screen or fully transparent
        if (particle.y > canvas.height || particle.opacity <= 0) {
            particles.splice(index, 1);
        }
    });
}

function drawParticles() {
    particles.forEach(particle => {
        ctx.fillStyle = particle.color;
        ctx.globalAlpha = particle.opacity; // Set opacity
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.globalAlpha = 1; // Reset global alpha
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    updateParticles();
    drawParticles();
    if (isAnimating || particles.length > 0) { // Continue animating if still animating or particles remain
        requestAnimationFrame(animate);
    }
}

const particleInterval = setInterval(createParticle, 100); // Create a new particle every 100 ms

// Stop the confetti after 10 seconds and start fading out
setTimeout(() => {
    isAnimating = false; // Stop the animation
    fadeOutStartTime = Date.now(); // Start fade out
    clearInterval(particleInterval); // Stop creating new particles
}, 10000); // 10 seconds

animate();

  }
 
//___________________Confeti Right Side ___________________

  
if ((x > canvas.width - cs && y > cs) || (x > canvas.width - cs && y > canvas.height - cs)){    
 const canvas = document.getElementById('confettiCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const colors = ['#ff0b00', '#00ff0b', '#00b3ff', '#ff00b3', '#ffb300'];
const particles = [];
let isAnimating = true; // To control the animation
let fadeOutStartTime = null; // To track fade out start time

function createParticle() {
    const size = Math.random() * 10 + 5;
    particles.push({
        x: Math.random() * canvas.width,
        y: 0,
        size: size,
        color: colors[Math.floor(Math.random() * colors.length)],
        speed: Math.random() * 3 + 1,
        angle: Math.random() * Math.PI * 2,
        opacity: 1 // Start fully opaque
    });
}

function updateParticles() {
    particles.forEach((particle, index) => {
        particle.y += particle.speed;
        particle.x += Math.sin(particle.angle) * 2;

        // Fade out effect
        if (fadeOutStartTime) {
            const elapsedTime = Date.now() - fadeOutStartTime;
            particle.opacity = Math.max(1 - elapsedTime / 2000, 0); // Fade out over 2 seconds
        }

        // Remove particle if it's off screen or fully transparent
        if (particle.y > canvas.height || particle.opacity <= 0) {
            particles.splice(index, 1);
        }
    });
}

function drawParticles() {
    particles.forEach(particle => {
        ctx.fillStyle = particle.color;
        ctx.globalAlpha = particle.opacity; // Set opacity
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.globalAlpha = 1; // Reset global alpha
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    updateParticles();
    drawParticles();
    if (isAnimating || particles.length > 0) { // Continue animating if still animating or particles remain
        requestAnimationFrame(animate);
    }
}

const particleInterval = setInterval(createParticle, 100); // Create a new particle every 100 ms

// Stop the confetti after 10 seconds and start fading out
setTimeout(() => {
    isAnimating = false; // Stop the animation
    fadeOutStartTime = Date.now(); // Start fade out
    clearInterval(particleInterval); // Stop creating new particles
}, 10000); // 10 seconds

animate();
}
  

  
  
  
  requestAnimationFrame(cycle);
}
requestAnimationFrame(cycle);
